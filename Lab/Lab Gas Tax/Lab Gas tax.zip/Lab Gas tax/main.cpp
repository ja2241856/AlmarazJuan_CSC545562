/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: 
 *Lab Gas Tax Program
 * Created on June 29, 2017, 11:45 PM
 */

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * The gas price is $4.00 from the article.
 */
int main()
{
    double exciseTax,salesTax,capTradeTax,federalExciseTax,companyProfit,totalGasTax,totalCompanyProfit;
    exciseTax = 0.39 / 4.00;
    salesTax = 0.08;
    capTradeTax = .10 / 4.00;
    federalExciseTax = (18.4 / 100.00);
    companyProfit = (0.07/4.00) * 100;
    
    totalGasTax = (exciseTax + capTradeTax + federalExciseTax + salesTax) * 100;
    totalCompanyProfit = companyProfit;
    cout <<"the total gas tax on a gallon is " <<totalGasTax<<" percent"<<endl;
    cout <<"the company profit is "<<totalCompanyProfit<<" % per gallon"<<endl;
    
    
    
    
    
  
    return 0;
}

