/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Carlos
 *
 * Created on July 5, 2017, 9:23 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() 
{
    char choice;
    choice <= 10;
    cout << "enter a number between 1-10"<<endl;
    cin >> choice;
    switch (choice)
    {
        case '1':cout<<"you entered I"<<endl;
        break;
        case '2':cout<<"you entered II"<<endl;
        break;
        case '3':cout<<"you entered III"<<endl;
        break;
        case '4':cout<<"you entered IV"<<endl;
        break;
        case '5':cout<<"you entered V"<<endl;
        break;
        case '6':cout<<"you entered VI"<<endl;
        break;
        case '7':cout<<"you entered VII"<<endl;
        break;
        case '8':cout<<"you entered VIII"<<endl;
        break;
        case '9':cout<<"you entered IX"<<endl;
        break;
        
      
        
    }
    return 0;
}

