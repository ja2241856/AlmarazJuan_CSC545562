

/* 
 * File:   main.cpp
 * Author: Carlos 
 *Minimum -Maximum Program 
 * Created on July 5, 2017, 8:34 PM
 */

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * 
 */
int main() 
{
  double number1,number2,Larger,Smaller;

  cout << "please enter two numbers" <<endl;
  cin >> number1;
  cin >> number2;
  {
    if (number1 > number2)
        number1 = Larger;
  cout<<Larger <<" is the larger number"<<endl;
        number2 = Smaller;
        cout<<Smaller << " is the smaller number " <<endl;
  }
  
  
  
    
   
    
    
    return 0;
}

